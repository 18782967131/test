from distutils.core import setup
setup(
name='traffic_pack',
version='1.0',
packages=[''],
author='neil'
)
