"""coding: utf-8

Copyright 2016 vArmour Networks private.
All Rights reserved. Confidential

VaTopo implements the class that abstracts the topology required to 
setup/cleanup testbed

.. moduleauthor:: autotest@sigma-rt.com
"""
import os, re, time,sys, pprint
from vautils import logger
from vautils.dataparser.test import VaTestInfo
from vautils.dataparser.yaml import load_yaml
from pprint import pprint
from IPy import IP

class VaTopo(object):
    """ 
    Class implements configure vlan, interface and route
    """
    def __init__(self, tb_yaml, topo_yaml,  **kwargs):
        """
        Initializes the topology object

        Kwargs:
            :testbed (obj): testbed object
        """
        self.testdata = VaTestInfo(tb_yaml, topo_yaml)
        self.link_info = self.testdata.va_get_links()
        self.ints_info = self.testdata.va_get_interfaces()
        self.route_info = self.testdata.va_get_routes()
        self.vmsobj = self.testdata.va_get_test_vms()
        self.swobjs = {}
        self.get_vsw_obj()  #get vswitch object

    def config_interfaces(self):
        logger.info("Start to config ip address")
        ints_info = self.ints_info

        for key in ints_info.keys() :
            devobj = self.testdata.va_get_by_uniq_id(key)
            node_type = self.testdata.va_get_by_uniq_id(key, False).get_nodetype() #linux or dir

            for int_info in ints_info[key] :
                if ( ( not 'auto_set' in  int_info) or (int_info['auto_set'] != 1) ) :
                    continue
                else :
                    #if auto_set =1 , it means to config ip address for defined interface
                    if node_type == 'linux' :
                        result = devobj.config_ip(int_info['ip'], int_info['name'])
                        if not result :
                            logger.debug(devobj.show_interface(int_info['name']))
                            return False
                    elif node_type == 'dir' :
                        result = devobj.va_set_ipv4(int_info['ip'], int_info['name'],True)
                        if not result :
                            return False
                    else:
                        #not support to config inteface for other device now
                        continue

        logger.info("Finished to set interface")
        return True

    def unset_interfaces(self):
        logger.info("Start to free address for device's interfaces")
        ints_info = self.ints_info

        for key in ints_info.keys() :
            devobj = self.testdata.va_get_by_uniq_id(key)
            node_type = self.testdata.va_get_by_uniq_id(key, False).get_nodetype() #linux or dir

            for int_info in ints_info[key] :
                if ( ( not 'auto_set' in  int_info) or (int_info['auto_set'] != 1) ) :
                    continue
                else :
                    #if auto_set =1 , it means to config ip address for defined interface
                    if node_type == 'linux' :
                        logger.info('Free address on {}:{}'.format(key,int_info['name']))
                        result = devobj.unconfig_ip(int_info['ip'], int_info['name'])
                        if not result :
                            logger.debug(devobj.show_interface(int_info['name']))
                            return False
                    elif node_type == 'dir' :
                        logger.info('Free address on {}:{}'.format(key, int_info['name']))
                        result = devobj.va_unset_ipv4(int_info['ip'], int_info['name'],True)
                        if not result :
                            return False
                    else:
                        #not support to config inteface for other device now
                        continue

        logger.info("Completed to unset interface")
        return True

    def config_routes(self):
        logger.debug("Start to config route")
        route_info = self.route_info

        for key in route_info.keys() :

            devobj = self.testdata.va_get_by_uniq_id(key,False)
            routes = route_info[key]
            node_type = devobj.get_nodetype()
            if (node_type == 'linux' or node_type == 'dir') :
                #only support linux pc and director now.
                devobj = self.testdata.va_get_by_uniq_id(key)
                for route in routes :
                    if (not 'auto_set' in route) or (route['auto_set'] != 1):
                        continue
                    else:
                        # if auto_set =1 , it means need to config route for defined pc
                        if node_type == 'linux':
                            result = devobj.config_route(route['dst'],route['netmask'],route['gateway'])

                        if node_type == 'dir':
                            #address netmask format.
                            if isinstance(route['netmask'],int) :
                                address = route['dst']+ '/' +route['netmask']
                            else :
                                address = route['dst'] + '/' + route['netmask']
                                tmp_addr = IP(address)
                                netmask = tmp_addr.prefixlen()
                                address = route['dst'] + '/' + str(netmask)
                            result = devobj.va_set_route(address, route['gateway'])

                        if not result :
                            logger.error('Failed to config route')
                            logger.debug(devobj.show_route())
                            logger.debug(devobj.show_interface())
                            return False

        logger.info("Completed to config route")
        return True

    def config_links(self):
        link_info = self.link_info
        logger.info("Start to config link")

        for link_key in link_info.keys() :
            num = 1
            for pc_key in link_info[link_key] :
                if num == 1 :
                    src_port_sw = link_info[link_key][pc_key]['interface']['vswitch']
                    src_portgroup = link_info[link_key][pc_key]['interface']['port_group']
                    src_int = link_info[link_key][pc_key]['interface']['phy_name']
                    src_dev = pc_key

                if num == 2 :
                    dst_port_sw = link_info[link_key][pc_key]['interface']['vswitch']
                    dst_portgroup = link_info[link_key][pc_key]['interface']['port_group']
                    dst_int = link_info[link_key][pc_key]['interface']['phy_name']
                    dst_dev = pc_key

                if 'vlan' in link_info[link_key][pc_key]:
                    vlan_val = link_info[link_key][pc_key]['vlan']

                hv_uqid = link_info[link_key][pc_key]['hyp_visor']['uniq_id']
                num += 1

            if (len(link_info[link_key]) ==2) and (src_port_sw != dst_port_sw)  :
                logger.error('The link is not in the same switch')
                return False
            else :
                if len(link_info[link_key]) ==2 :
                    logger.info('Connection:{} Access vlan ({}),from {}:{}, to {}:{}, switch : {}'\
                                .format(link_key,vlan_val,src_dev,src_int,dst_dev,dst_int,src_port_sw))
                else :
                    logger.info('Connection:{} Access vlan ({}),{}:{}, switch : {}' \
                                .format(link_key, vlan_val, src_dev, src_int, src_port_sw))

                vswobj = self.swobjs[hv_uqid][src_port_sw]
                if not vswobj.update_vlan(src_portgroup,vlan_val) :
                    return  False

                #update portgroup for destination pc/device if need
                if len(link_info[link_key]) == 2 :
                    if not vswobj.update_vlan(dst_portgroup,vlan_val)  :
                        return False

        vswobj.show_sw()

        logger.info("Completed to config link")
        return True

    def get_vsw_obj(self):
        inventory_tb_data = load_yaml(self.testdata.inventory_file)
        self.swobjs = {}

        for dev_key in inventory_tb_data.keys() :
            for dev in inventory_tb_data[dev_key]:
                if 'type' in dev and dev['type'] == 'esxi' :
                    continue

                hvid = dev['hvisor']['uniq_id']
                if not hvid in self.swobjs:
                    self.swobjs[hvid] = {}

                if not 'hvobj' in self.swobjs[hvid] :
                    self.swobjs[hvid]['hvobj'] = self.testdata.va_get_by_uniq_id(hvid, False)
                    self.swobjs[hvid]['hvobj'].setup_vswitch(self.swobjs[hvid]['hvobj'].get_shell())

                for int in dev['interfaces']:
                    sw_name = int['vswitch']
                    if not sw_name in self.swobjs[hvid] :
                        self.swobjs[hvid][sw_name] = self.swobjs[hvid]['hvobj'].get_vswitch(sw_name)
        logger.info(self.swobjs)
        return self.swobjs

    def revert_links(self):
        inventory_tb_data = load_yaml(self.testdata.inventory_file)
        swobjs = {}

        for dev_key in inventory_tb_data.keys() :
            for dev in inventory_tb_data[dev_key]:
                if not 'interfaces' in dev or len(dev['interfaces']) == 0:
                     continue
                else :
                    vswitches = dev['hvisor']['vswitches']
                    vswitches_l = vswitches.split(' ')

                    for int in dev['interfaces'] :
                        logger.debug('Check switch {} if it is in hv {}'.format(int['vswitch'],
                                                                             dev['hvisor']['mgmt_ip']))
                        tag = 0
                        for vswname in vswitches_l:
                            if vswname == int['vswitch'] :
                                logger.debug('check vswitch on hv.done')
                                tag = 1
                                break

                        if tag == 0 :
                            logger.error('vswitch {} is not in hv {}' . format (int['vswitch'], \
                                                                                dev['hvisor']['mgmt_ip']))
                            return False

                        #update vlan for each interface
                        logger.info('Clean access vlan {} for {}:{}'\
                                    .format(int['vlan'],dev['uniq_id'],int['phy_name']))
                        hv_uqid = dev['hvisor']['uniq_id']
                        vswobj = self.swobjs[hv_uqid][int['vswitch']]
                        if not vswobj .update_vlan(int['port_group'], int['vlan']) :
                            return False

        logger.info("Completed to revert links")
        return True

    def setup(self, **kwargs):
        """
        Implementation of setup of the topology.

        Kwargs:
        Returns:
            :0/1: failed/succeed
        """
        logger.info("*********************************")
        logger.info("*                                ")
        logger.info("* Start to setup topology        ")
        logger.info("*                                ")
        logger.info("*********************************")

        #Config links
        if not self.config_links():
            logger.error('Failed to configure links')
            return False

        #Config interface
        if not self.config_interfaces():
            logger.error('Failed to configure ip address of interfaces')
            return False

        #Config interface
        if not self.config_routes():
            logger.error('Failed to configure routes')
            return False

        logger.debug("*********************************")
        logger.debug("*                                ")
        logger.debug("* Finished to setup topology     ")
        logger.debug("*                                ")
        logger.debug("*********************************")
        return True

    def cleanup(self, **kwargs):
        """
        Implementation of destroy of the topology.

        Kwargs:
        Returns:
            :0/1: failed/succeed
        """
        logger.info("*********************************")
        logger.info("*                                ")
        logger.info("* Start to clean topology        ")
        logger.info("*                                ")
        logger.info("*********************************")
        #Remove interface
        if not self.unset_interfaces():
            logger.error('Failed to remove ip address of interfaces')
            return False
        
        #Remove link
        if not self.revert_links():
            logger.error('Failed to revert links')
            return False

        logger.info("*********************************")
        logger.info("*                                ")
        logger.info("* Finished to clean topology     ")
        logger.info("*                                ")
        logger.info("*********************************")
        return True

    def __del__(self):
        """
        unlinking the reference to the inventory instance.
        """
        self._inventory = None
        self.testdata = None
        self.link_info = None
        self.ints_info = None
        self.route_info =  None
        self.vmsobj = None
        self.swobjs = None

if __name__ == '__main__' :
    test_param_file = 'D:\VATF\lib\\vats\demo\\fabric_test_example\params\\test_param.yaml'
    topo_file = 'D:\VATF\lib\\vats\demo\\fabric_test_example\params\\epi_topo.yaml'
    vatpobj = VaTopo(test_param_file, topo_file)
    vatpobj.setup()
    vatpobj.cleanup()
