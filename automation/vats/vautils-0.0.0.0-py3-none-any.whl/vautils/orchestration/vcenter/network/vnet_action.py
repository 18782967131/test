"""
coding: utf-8

Copyright 2016 vArmour Networks private.
All Rights reserved. Confidential

vCenterHost class is representing vim.HostSystem ESXi Host objects and its methods.
class methods either return string or managed objects.

.. moduleauthor::jpatel@varmour.com

"""

#TODO Need to Implement vCenter Network Action Class