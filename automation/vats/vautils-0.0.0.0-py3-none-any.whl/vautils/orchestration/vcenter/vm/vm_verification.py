"""
coding: utf-8

Copyright 2016 vArmour Networks private.
All Rights reserved. Confidential

VmVerification class is using for VM related verifications.

.. moduleauthor::jpatel@varmour.com

"""


from utils.orchestartion.vcenter.vcenter_connector import VcenterConnector


# No Need to Implement This Class Now

class VmVerification():
    pass
