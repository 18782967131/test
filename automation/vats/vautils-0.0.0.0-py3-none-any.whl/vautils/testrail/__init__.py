"""coding: utf-8

Testrail test case fields to log additional information  

"""

FIELD_TESTCASE_REF = "Testcase Ref"
FIELD_SUMMARY = "Summary"
FIELD_STEPS = "Steps"
