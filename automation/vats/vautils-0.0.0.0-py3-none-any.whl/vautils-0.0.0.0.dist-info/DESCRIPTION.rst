utils
-----
Package implements vautils, a library to simulate network traffic,
config features of third party software like linux, windows,
vcenter. The package also implements data parser utilities, logging
utilities that are used framework wide. 


