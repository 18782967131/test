#!/usr/bin/env python3

import sys,argparse
from vautils.va_topo import VaTopo

parser = argparse.ArgumentParser()
parser.add_argument(
    '-t', '--test',
    type=str,
    help='test parametes yaml for the lab. example : D:\VATF\lib\\vats\demo\\fabric_test_example\params\\test_param.yaml'
    )
parser.add_argument(
    '-tp', '--topo',
    type=str,
    help='device information and connection information, example: D:\VATF\lib\\vats\demo\\fabric_test_example\params\\epi_topo.yaml'
)
args = parser.parse_args()

test_param_file = args.test
topo_file = args.topo

vatpobj = VaTopo(test_param_file, topo_file)
vatpobj.setup()
vatpobj.cleanup()