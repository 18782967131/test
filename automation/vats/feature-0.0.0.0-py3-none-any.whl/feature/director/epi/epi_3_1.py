"""coding: utf-8

Copyright 2016 vArmour Networks private.
All Rights reserved. Confidential

Epi abstracts epi related features. A superset of features apply
to the product 'dir', while a subset of features apply to other products
- cp, ep, epi. It inherits from class VaSystem, where all the common
features are implemented.

.. moduleauthor:: ppenumarthy@varmour.com, mzhao@varmour.com
"""
import sys
import re
import time
from collections import namedtuple

from feature.common import VaFeature
from feature import logger
from vautils.dataparser.string import va_parse_basic, va_parse_as_lines

class VaEpi(VaFeature):
    """
    Epi implements methods to configure or view the EPI related
    features.
    """
    def va_show_chassis_epi(self, host_id=None):
        """
        method to get chassis epi information.

        kwargs:
            :host_id (str): uuid of the epi or the hostname

        returns:
            :dict: dict of parsed information
        """
        cmd = "show chassis epi"
        parser = self._va_parse_chassis_epi
        if host_id:
            cmd = "show chassis epi {}".format(host_id)
            parser = va_parse_basic

        output = self._access.va_cli(cmd)
        return parser(output)

    def _va_parse_chassis_epi(self, output=None):
        """
        helper method to parse 'show chassis epi uuid' or
        'show chassis epi hostname'

        returns (dict): look at the following output

        {
            "Active EPI":[
                [
                    "420135BF-0069-120D-816E-29A058C829ED",
                    "VA-31-EPi1",
                    "2-6",
                    "tap",
                    "100.0.92.84/24",
                    "10.150.92.84/16",
                    "@Thu",
                    "Jul",
                    "28",
                    "09:13:56",
                    "2016",
                    "TLS",
                    "yes"
                ],
                [
                    "42015F2D-48F1-6C65-21F9-4C25756818BC",
                    "-",
                    "3-6",
                    "tap",
                    "100.0.92.86/24",
                    "10.150.92.86/16",
                    "@Thu",
                    "Jul",
                    "28",
                    "08:56:53",
                    "2016",
                    "TLS",
                    "yes"
                ]
            ],
            "Total inactive EPIs":" 0",
            "Inactive EPI":[],
            "Total active EPIs":" 2"
        }
        """
        parsed = dict()
        Epi = namedtuple('Epi', ['uuid', 'hostname', 'epi_id', 'mode',
                                 'fabric_ip', 'management_ip', 'weekday',
                                 'month', 'day', 'time', 'year',
                                 'connected_type', 'licensed'])

        current_key = None
        for line in va_parse_as_lines(output):
            line = line.lstrip()
            if line.startswith('Active') or line.startswith('Inactive'):
                current_key = line.rstrip(':')
                parsed[current_key] = list()
            elif not line.startswith('UUID')\
                    and not line.startswith('-')\
                    and not line.startswith('Total')\
                    and not line.startswith('*:'):
                values = line.split()
                parsed[current_key].append(tuple(values))
            elif line.startswith('Total'):
                key, value = line.split(':')
                parsed[key] = value
            else:
                continue

        return parsed

    def va_get_epi_uuid (self, *args, **kwargs):

        """
        method to get epi uuid by epi mgt ip
        param      : kwargs : dict
        example    : va_get_epi_uuid(**kwargs)
                   kwargs = {
                    'epi_obj': EPI1
                   }
        return: uuid if given epi_object, a list of uuid if not specify, None
            on failure
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)   

        epi_uuid = list() 

        epi_info = self.va_show_chassis_epi()
        uuid_info = epi_info.get('Active EPI')
        if len(uuid_info) == 0 :
            logger.error("Not found any EPI")
            return None

        for info in uuid_info:
            if 'epi_obj' in kwargs:
                epi_obj = kwargs.get('epi_obj')
                epi_mgt_ip = epi_obj._resource.get_mgmt_ip()
                if re.search(epi_mgt_ip, ' '.join(info)) is not None:
                    epi_uuid.append(info[0].strip())
                    epi_uuid = epi_uuid[0]
                    break
            else:
                epi_uuid.append(info[0].strip())

        if len(epi_uuid) == 0:
            logger.error("Failed to get uuid of EPI")
            return None

        logger.info("UUID: {}".format(epi_uuid))
        return epi_uuid

    def va_get_epi_status(self, *args, **kwargs):
        """
        method to check epi status 
        param      : kwargs : dict
        example    : va_get_epi_status(kwargs)
                   kwargs = {
                    'uuid': 'xxx'
                   }
        return: 'active' or 'inactive' or None (if epi not found)
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)
   
        if not 'uuid' in kwargs :
            raise ValueError(" uuid is mandatory parameter!\n") 

        uuid = kwargs['uuid']
        epi_info = self._access.va_cli('show chassis epi')
        (active_epi_info, inactive_epi_info) = epi_info.split("Inactive EPI")
        status = ""
        
        res = re.search(uuid,active_epi_info)   
        if res is not None:
           status = 'active'
        else:
            res = re.search(uuid,inactive_epi_info)
            if res is not None:
                status = 'inactive'
            else:
                logger.error("Not found EPI: {}".format(uuid))
                return None

        logger.info('Status of EPI: {}'.format(status))
        return status

    def va_config_epi_operation_mode(self, *args, **kwargs):

        """
        method to config epi operation mode 
        param      : kwargs : dict
        example    : va_config_epi_operation_mode(**kwargs)
                   kwargs = {
                    'uuid': '564DB44A-B3F3-5D0B-0C33-77CD43987BFC'
                    'mode': 'inline'|'tap'|'pvlan'
                    'is_commit': True|False, True by default
                   }
        return: a tuple of True and cmd on success, False and err_msg on failure
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)   
        
        if not 'mode' in kwargs or \
            not 'uuid' in kwargs:
            raise ValueError(" 'mode' and 'uuid' are mandatory parameters!\n") 
        
        is_commit = True
        uuid = kwargs.get('uuid')
        mode = kwargs.get('mode')
        if 'is_commit' in kwargs:
            is_commit = kwargs.get('is_commit')

        cmd = 'set chassis epi {} operation-mode {}'.format(uuid, mode)
        ret_val, err_msg = self._access.va_config(cmd, commit=is_commit)
        if ret_val is not None:
            return False, err_msg

        logger.info('Succeed to configure operation mode of EPI')
        return True, cmd 
        
    def va_config_micro_segmentation(self, *args, **kwargs):
        """
        API to config micro segmentation of EPI
        param      : kwargs : dict
                       'uuid'      : uuid of epi,
                       'segment_id': segment id of epi,
                       'micro_vlan': micro-vlan primary value of epi,
                       'pvlan'     : micro-vlan secondary value of epi,
                       'is_commit' : commit commands, True or False, True by default
        example    : va_config_micro_segmentation(**kwargs)
                     kwargs = {
                       'uuid': '564DB44A-B3F3-5D0B-0C33-77CD43987BFC'
                       'segment_id': 3000
                       'micro_vlan': 100
                       'pvlan'     : 200
                      }
        return: a tuple of True and cmd on success, False and err_msg on failure
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)   
        
        if not 'uuid' in kwargs or \
            not 'segment_id' in kwargs or \
            not 'micro_vlan' in kwargs:
            raise ValueError(" 'uuid', 'segment_id' and 'micro_vlan' \
are mandatory parameters!\n") 

        is_commit = True
        uuid = kwargs.get('uuid')
        segment_id = kwargs.get('segment_id')
        micro_vlan = kwargs.get('micro_vlan')
        if 'is_commit' in kwargs:
            is_commit = kwargs.get('is_commit')

        cmd = 'set micro-segmentation epi {} segment {} micro-vlan {}'.format(
            uuid, segment_id, micro_vlan)
        if 'pvlan' in kwargs:
            pvlan = kwargs.get('pvlan')
            cmd += ' micro-vlan-2nd {}'.format(pvlan)

        ret_val, err_msg = self._access.va_config(cmd, commit=is_commit)
        if ret_val is not None:
            return False, err_msg

        logger.info('Succeed to configure micro segmentation of EPI')
        return True, cmd 
    
    def va_check_chassis_epi_status(self):

        """
        API to check chassis status of EPI.
        return:
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        chassis_info = self.va_show_chassis_epi()
        inactive_count = int(chassis_info.get('Total inactive EPIs'))
        if inactive_count != 0:
            logger.error('Found inactive EPis: {}'.format(inactive_count))
            return False

        logger.info('All EPis are connected')
        return True

    def va_get_epi_connecting_mode(self, *args, **kwargs):
        """
        API to get connecting mode of EPI.
        param   : kwargs : dict
        example : va_get_epi_connecting_mode(**kwargs)
            kwargs = {
                    'epi_obj' : a object of EPI,
            }
        return: 
            :string - None or connecting mode(primary/backup)
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        epi_mode = None

        if not 'epi_obj' in kwargs :
           raise ValueError("epi_obj is mandatory parameter!\n") 
        epi_obj = kwargs['epi_obj']
        epi_mgt_ip = epi_obj._resource.get_mgmt_ip()
        if 'epi_mgt_ip' not in dir():
            logger.error("Failed to get management ip of EPI")
            return epi_mode

        epi_info = self.va_show_chassis_epi()
        epi_info = epi_info.get('Active EPI')
        if len(epi_info) == 0:
            return epi_mode

        for info in epi_info:
            info = ' '.join(info)
            if re.search(epi_mgt_ip, info) is not None:
                match_result = re.search(r'([\d-]+)\s+(\*\#|\*?)\s+', info)
                if match_result is not None:
                    epi_mode = 'backup' 
                else:
                    epi_mode = 'primary' 
                break

        logger.info("EPI is connecting to its '{}' EP/CP".format(epi_mode))
        return epi_mode

    def va_reconnect_epi(self, *args, **kwargs):
        """
        API to reconnect epi
        param   : kwargs : dict
        example : va_reconnect_epi(**kwargs)
            kwargs = {
                    'epi' : uuid|hostname,
                    'dev_id' : device id,
            }
        return: 
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        cmd = 'request system reconnect'
        if 'epi' in kwargs:
            epi = kwargs.get('epi')
            cmd = '{} epi {}'.format(cmd, epi)
            if 'dev_id' in kwargs:
                dev_id = kwargs.get('dev_id')
                cmd = '{} device {}'.format(cmd, dev_id)
            else:
                cmd = '{} primary'.format(cmd)

        output = self._access.va_cli(cmd)
        return True

    def va_get_epi_forwarding_table(self, *args, **kwargs):
        """
        get epi forwarding table according to uuid or hostname of epi
        param   : kwargs : dict
            kwargs = {
                    'epi' : uuid or hostname of the epi. eg: 2-6 or epi6
            }
        return: tuple
            Success: True,
                : {'0:50:56:8e:ed:8': {
                            'EPI-MAC': 'local',
                            'EPI-IP': 'local',
                            'SEG-ID': '3000',
                            'MICRO-VLAN': '2003',
                            'VM-MAC': '0:50:56:8e:ed:8',
                            'FLAG': '110'},
                   'Total remote entries': '0',
                   'Total local entries': '2',
                   '0:c:29:51:77:f8': {
                         'EPI-MAC': 'local',
                         'EPI-IP': 'local',
                         'SEG-ID': '3000',
                         'MICRO-VLAN': '2002',
                         'VM-MAC': '0:c:29:51:77:f8',
                         'FLAG': '110'
                         }
                   }
            Failure: False,{}
        example : va_get_epi_forwarding_table(**kwargs)

        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)
        return_data = {}
        if not 'epi' in kwargs :
            raise ValueError("uuid of hostname of epi is mandatory parameter!\n")

        cmd = 'show chassis epi {} forwarding'.format(kwargs.get('epi'))
        output = self._access.va_cli(cmd)
        if re.search(r'Fail to find EPI',output, re.M|re.I) is not None :
            logger.error('Failed to find EPI {}'.format(kwargs.get('epi')))
            return False,return_data

        output = output.split('\n')
        output.pop(0)
        last_index = len(output) - 1
        output.pop(int(last_index))
        output.pop(1)

        #address the number of tatal local/remove entries
        for i in range (1,3) :
            total_line = output.pop(-1).split(':')
            return_data[total_line[0].strip()] = total_line[1].strip()

        #get key name
        key_name = output.pop(0)
        key_name = key_name.split()

        #get forwarding information for each vm-mac
        for fw_in in output :
            fw_in_l = fw_in.split()
            num = len(fw_in_l)
            vm_mac = fw_in_l[0]
            return_data[vm_mac] = {}
            for i in range(0,num) :
                fw_in_e_v = fw_in_l[i].strip()
                fw_in_e_k = key_name[i].strip()
                return_data[vm_mac][fw_in_e_k] = fw_in_e_v
        logger.debug('forwaing table of {} epi is {}\n'.format(kwargs.get('epi'),return_data))
        return True,return_data

    def va_check_epi_forwarding_table(self, *args, **kwargs):
        """
        check epi forwarding table if it is correct according to the value of epi,vm-mac, micro-vlan and seg-id
         or option parameter (epi-mac, epi-ip and flag)
        param   : kwargs : dict
            kwargs = {
                    'epi' : uuid or hostname of the epi. eg: 2-6 or epi6
                    'fw_data' :[
                       {
                            'EPI-MAC': the value of epi-mac[option],
                            'EPI-IP': the value of epi ip[Option]
                            'SEG-ID': 'the value of seg id
                            'MICRO-VLAN': the value of micor vlan
                            'VM-MAC': the value of vm mac
                            'FLAG': the value of flag[option]}
                        }
                    ],
                    'Total remote entries' : option,
                    'Total local entries': option
            }
        return: bool
            Success: return True
            Failure: return False
        example :
             va_check_epi_forwarding_table(**kwargs)
             kwargs = {
                'epi': '2-6',
                'fw_data': [
                    {
                        'EPI-MAC': 'local',
                        'EPI-IP': 'local',
                        'SEG-ID': '3000',
                        'MICRO-VLAN': '2002',
                        'VM-MAC': '0:c:29:51:77:f8',
                        'FLAG': '111'
                     },
                     {'SEG-ID': '3000', 'MICRO-VLAN': '2003', 'VM-MAC': '0:50:56:8e:ed:8'}],
                     'Total local entries' : 2,
                     'Total remote entries': 0

            }
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)
        if not 'epi' in kwargs :
            raise ValueError("uuid of hostname of epi is mandatory parameter!\n")

        if not 'fw_data' in kwargs :
            raise ValueError("fw_table is mandatory parameter!\n")

        result,forwarding_info = self.va_get_epi_forwarding_table(**{'epi': kwargs.get('epi')})

        if result == False :
            return False

        expect_fw_data = kwargs.get('fw_data')

        if 'Total remote entries' in kwargs :
            expect_val = int(kwargs.get('Total remote entries'))
            actual_val = int(forwarding_info.get('Total remote entries'))
            if actual_val != expect_val :
                logger.error('The value of total remove entries is incorrect')
                logger.debug('Expect value of total remove entries is {}'.format(expect_val))
                logger.debug('Actual value of total remove entries is {}'.format(actual_val))
                return False

        if 'Total local entries' in kwargs:
            expect_val = int(kwargs.get('Total local entries'))
            actual_val = int(forwarding_info.get('Total local entries'))
            if actual_val != expect_val:
                logger.error('The value of Total local entries is incorrect')
                logger.debug('Expect value of Total local entries is {}'.format(expect_val))
                logger.debug('Actual value of Total local entries is {}'.format(actual_val))
                return False

        for each_fw_info in expect_fw_data:
            vm_mac = each_fw_info.get('VM-MAC')
            micro_vlan = each_fw_info.get('MICRO-VLAN')
            seg_id = each_fw_info.get('SEG-ID')
            if not vm_mac.strip() in forwarding_info:
                logger.error('Not found vm_mac {} in forwarding table'.format(vm_mac))
                return False

            actual_fw =  forwarding_info.get(vm_mac.strip())
            if vm_mac.strip() != actual_fw.get('VM-MAC') or \
                micro_vlan.strip() != actual_fw.get('MICRO-VLAN') or \
                seg_id.strip() != actual_fw.get('SEG-ID') :
                logger.error('Verification failure!!!')
                logger.debug('Expect value are:vm_mac:{},micro_vlan:{},\
                seg_id:{}'.format(vm_mac,micro_vlan,seg_id))
                logger.debug('Acutal values are:vm_mac:{},micro_vlan:{},\
                seg_id:{}'.format(actual_fw.get('VM-MAC'),actual_fw.get('MICRO-VLAN'),actual_fw.get('SEG-ID')))
                return False

            if 'EPI-MAC' in each_fw_info :
                epi_mac = each_fw_info.get('EPI-MAC')
                if epi_mac != actual_fw.get('EPI-MAC') :
                    logger.error('Verification failure for EPI-MAC. expect value:{}, \
                    actual value:{}'.format(actual_fw.get('EPI-MAC'),epi_mac))
                    return False

            if 'EPI-IP' in each_fw_info :
                epi_ip =each_fw_info.get('EPI-IP')
                if epi_ip != actual_fw.get('EPI-IP'):
                    logger.error('Verification failure for EPI-IP. expect value:{}, \
                                actual value:{}'.format(actual_fw.get('EPI-IP'), epi_ip))
                    return False

            if 'FLAG' in each_fw_info:
                flag = each_fw_info.get('FLAG')
                if flag != actual_fw.get('FLAG'):
                    logger.error('Verification failure for FLAG. expect value:{}, \
                                actual value:{}'.format(actual_fw.get('FLAG'), flag))
                    return False
            logger.info('Succeed to check forwaring for vm_mac {}'.format(vm_mac))

        logger.info('Succeed to check forwarding for epi {}'.format(kwargs.get('epi')))
        return True
