"""coding: utf-8

Copyright 2016 vArmour Networks private.
All Rights reserved. Confidential

System abstracts system related features. A superset of features apply
to the product 'dir', while a subset of features apply to other products
- cp, ep, epi. It inherits from class VaSystem, where all the common
features are implemented.

.. moduleauthor:: ppenumarthy@varmour.com, mzhao@varmour.com
"""

import sys
import re
import time
import copy
from collections import namedtuple
from feature.common.system.system_3_1 import VaSystem as System
from feature.director.network.network_3_1 import VaNetwork as Network
from feature.director.epi.epi_3_1 import VaEpi
from feature import logger
from vautils.dataparser.string import va_parse_basic, va_parse_as_lines


class VaSystem(System, Network, VaEpi):
    """
    System implements methods to configure or view the system related
    features.
    """
    def va_disable_paging(self):
        """
        method to set the terminal page length to 0. This will cause the
        entire output to be read once - instead of one page at a time.
        """
        self._access.va_disable_paging()
        result = self._access.va_cli('show cli page')

        parsed = va_parse_basic(result)
        if int(parsed.get('Terminal length')) == 0:
            logger.info("successfully disabled paging!")
            return True

    def va_show_chassis(self):
        """
        method to get chassis information.
        """
        cmd = "show chassis"
        output = self._access.va_cli(cmd)

        return self._va_parse_chassis(output)

    def va_show_running_config(self):
        """
        method to get running configuration on the varmour vm.
        """
        cmd = "show running-config"
        output = self._access.va_cli(cmd)

        return va_parse_as_lines(output)

    def va_show_config_status(self):
        """
        method to get configuration status.

        returns:
            :list: list of namedtuple please see the parser method for more
                   info
        """
        cmd = "show config status"
        output = self._access.va_cli(cmd)

        return self._va_parse_config_status(output)

    def _va_parse_chassis(self, output=None):
        """
        helper method to parse 'show chassis'

        returns (dict):

        {
            "virtual chassis setup":{
                "virtual-mac":"disabled",
                "session distribution method":"ingress-first",
                "image-operation delay":"60 seconds",
                "fabric default gateway":"0.0.0.0",
                "control fabric ip":"100.0.92.81/24",
                "management default gateway":"10.150.0.1",
                "control fabric interface":"xe-1/0/0",
                "datapath id":"00:00:00:50:56:81:c4:33",
                "management ip":"10.150.92.81",
                "configuration version":"0x33",
                "virtual-mac identifier":"127",
                "chassis identifier":"vArmour",
                "control protocol/port":"tcp/6634"
            },
            "EPI controller recovery":{
                "commit time":"10 minutes",
                "status":"enabled"
            },
            "openflow controller":{
                "controller ip":"0.0.0.0",
                "connected since":"not connected",
                "controller protocol/port":"NA/0"
            },
            "interfaces registered":{
                "logical":"19",
                "physical":"16"
            },
            "devices status":{
                "total devices connected":"5 (0 ASG devices, 5 vm instances)",
                "last device joined":"device 2 @ Thu Jul 28 09:10:42 2016",
                "total inactive EPIs ":"0",
                "inactive devices":"2 (device id: 4,5)",
                "total EPIs connected":"2"
            }
        }
        """
        parsed = dict()

        outer_key = None
        for line in va_parse_as_lines(output):
            if ':' not in line and not line.startswith('-'):
                if line.strip():
                    outer_key = line
                    parsed[outer_key] = dict()
            else:
                if not line.startswith('-'):
                    inner_key, value = line.split(':', 1)
                    parsed[outer_key][inner_key] = value.strip()

        return parsed

    def _va_parse_config_status(self, output=None):
        """
        helper method to parse config status

        [
            [
                "1",
                "10.150.92.101/16",
                "DIR",
                "0x1c",
                "2016-07-30_20:56:27_UTC",
                "InSync"
            ]
        ]
        """
        parsed = list()
        Config = namedtuple('Config', ['dev', 'mgmt_ip', 'mode', 'version',
                                       'commit_timestamp', 'status'])

        for line in va_parse_as_lines(output):
            line = line.lstrip()
            if not line.startswith('DEV')\
                    and not line.startswith('-')\
                    and not line.startswith('Director'):
                values = line.split()
                try:
                    parsed.append(Config(*values))
                except TypeError:
                   pass

        return parsed

    def va_check_chassis_status(self, *args, **kwargs):
        """
        API to check status of chassis
        param   : kwargs : dict
                : va_check_chassis_status(**kwargs)
            kwargs = {
                    'dev_obj' : device object,
                    'dev_ids' : device id,
            }
        example : va_check_chassis_status(dev_obj=cp_1, dev_ids=2)
                : va_check_chassis_status(dev_obj=[cp_1, cp_2], dev_ids=[2, 3])
        return:
            :bool - True on success or False on failure:
 
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)
        chassis_info = self.va_show_chassis()
        inactive_info = chassis_info.get('devices status').get(
            'inactive devices')
        pat = re.compile(r'(\d+)\s+')
        match_result = pat.search(inactive_info)
        inactive_count = int(match_result.group(1))

        if 'is_ha' in args:
            total_info = chassis_info.get('devices status').get(
                'total devices connected')
            match_result = pat.search(total_info)
            total_count = int(match_result.group(1))
            active_count = total_count - inactive_count
            if active_count != 1 and int(inactive_count) != 0:
                logger.error('Found inactive device: {}'.format(inactive_count))
                return False
        else:
            if inactive_count != 0:
                logger.error('Found inactive device: {}'.format(inactive_count))
                return False
            if not self.va_check_chassis_epi_status():
                return False

        if 'dev_obj' in kwargs and 'dev_ids' in kwargs:
            if not self.va_check_interfaces_order(**kwargs):
               return False

        logger.info('All devices are connected')
        return True

    def va_check_configured_cmds(self, *args, **kwargs):
        """
        API to check if commands are configured 
        param   : kwargs : dict
        example : va_check_configured_cmds(**kwargs)
            kwargs = {
                    'cmdList' : a list of checking commands,
                    'type'    : 'regexp',
            }
        return:
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        if 'cmdList' in kwargs :
            cmdList = kwargs.get('cmdList')
        else:
            raise ValueError("cmdList is mandatory parameter!\n") 
        logger.info("Check CMD: {}".format(cmdList))

        if not 'type' in kwargs :
            type = 'regexp'
        else :
            type = kwargs.get('type')
        
        infoList = self.va_show_running_config()

        for cmd in ['exit', 'configure', 'commit', '']:
            if cmdList.count(cmd) > 0:
                cmdList.remove(cmd)
            if infoList.count(cmd) > 0:
                infoList.remove(cmd)
        
        results = True
        for get_setted_cmd in cmdList:
            get_setted_cmd = get_setted_cmd.strip()
            get_setted_cmd = re.sub(r'^unset ', 'set ', get_setted_cmd)
            for get_cmd in infoList:
                if re.search(r'^set', get_cmd) is not None:
                    if (type == 'regexp') :
                        intf_pat = "(set interface .* unit)"
                        unit_pat = "(\d+)-(\d+)"
                        if re.search(r"{}\s+(.*)".format(intf_pat), get_setted_cmd):
                            interface_pre = re.search(r"{}".format(intf_pat),\
                                            get_setted_cmd).group(0)
                            interface_unit = re.search(r"{}\s+(.*)".format(intf_pat),\
                                             get_setted_cmd).group(1)
                            if re.search(interface_pre,get_cmd) :
                                pat = re.compile(r"{}".format(unit_pat))
                                interface_unit_active = re.search(r"unit\s+(.*)", 
                                    get_cmd).group(1)
                                interface_unit_list = interface_unit_active.split(',')
                                src_unit = interface_unit.split(',')
                                dst_unit = interface_unit_active.split(',')
                                src_unit_list = []
                                dst_unit_list = []
                                for unit_id in src_unit :
                                    if pat.search(unit_id):
                                        temp_re = pat.search(unit_id)
                                        start_id = temp_re.group(1)
                                        end_id = temp_re.group(2)
                                        for temp_id in range(int(start_id),int(end_id)+1):
                                            src_unit_list.append(str(temp_id))
                                    else :
                                        src_unit_list.append(str(unit_id))
                                for unit_id in dst_unit :
                                    if pat.search(unit_id):
                                        temp_re = pat.search(unit_id)
                                        start_id = temp_re.group(1)
                                        end_id = temp_re.group(2)
                                        for temp_id in range(int(start_id),int(end_id)+1):
                                            dst_unit_list.append(str(temp_id))
                                    else :
                                        dst_unit_list.append(str(unit_id))
                                union_list = set(src_unit_list + dst_unit_list)
                                if len(union_list) == len(dst_unit_list):
                                    result = True
                                    break
                                else :
                                    result = False
                                    break
                            else :
                                result = False
                            continue
                        if re.search(get_setted_cmd, get_cmd, re.I) is not None:
                            result = True
                            break
                        else:
                            result = False
                    else :
                        if (get_cmd == get_setted_cmd):
                            result = True
                            break
                        else:
                            result = False
            results = results & result
            if result:
                infoList.remove(get_cmd)
                logger.info("Matched: {}".format(get_setted_cmd))
            else:
                logger.error("Not matched: {}, {}".format(get_setted_cmd, 
                    get_cmd))

        if not results:
            logger.error('Some commands are not in running configurations')
            return False

        logger.info('Succeed to check all configured commands')
        return True

    def va_check_config_status(self):

        """
        API to check status of configuration.
        return:
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        status_info = self.va_show_config_status()
        for info in status_info:
            if info.status == 'mismatch':
                logger.error('Found "mismatch" in status of configuration: \
{}'.format(status_info))
                return False

        logger.info('Succeed to check status of configuration')
        return True

    def va_check_system_timestamp(self, *args, **kwargs):

        """
        API to check timestamp of system.
        param   : kwargs : dict
        example : va_check_system_timestamp(**kwargs)
            kwargs = {
                    'epi_obj' : a object of EPI,
            }
        return:
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)
        
        if 'epi_obj' in kwargs:
            epi_obj = kwargs.get('epi_obj')
            epi_mgt_ip = epi_obj._resource.get_mgmt_ip()
            if 'epi_mgt_ip' not in dir():
                logger.error('Failed to get mangement ip of EPI')
                return False

            epi_mgt_ip = {'mgt_ip' : epi_mgt_ip}
            epi_uuid = self.va_get_epi_uuid(**epi_mgt_ip)
        else:
            epi_uuid = self.va_get_epi_uuid()

        if 'epi_uuid' not in dir() or epi_uuid is None:
            return False

        system_info = self.va_show_system()
        global_timestamp = system_info.get('global commit timestamp')
        for uuid in epi_uuid:
            epi_info = self.va_show_chassis_epi(uuid)
            epi_timestamp = epi_info.get('Commit timestamp')
            if global_timestamp != epi_timestamp:
                logger.error('The timestamp {} is different from EPi {}'.format(
                    global_timestamp, epi_timestamp))
                return False

        logger.info('Succeed to check timestatmp')
        return True

    def va_show_session(self, *args, **kwargs):
        """
        API to get session.
        param   : kwargs : dict
        example : va_show_session(**kwargs)
            kwargs = {
                    'dst_ip'    : '2.2.2.2',
                    'app_id'    : 'icmp',
                    'interface' : 'xe-2/0/0.1',
                    'policy'    : '1', Policy Index,
                    'epi'       : '2-7', UUID | hostname
            }
        return: session or None
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        if 'dst_ip' in kwargs:
            filter = 'match dst-ip {}'.format(kwargs.get('dst_ip'))
        elif 'app_id' in kwargs:
            filter = 'match app-id {}'.format(kwargs.get('app_id'))
        elif 'interface' in kwargs:
            filter = 'match interface {}'.format(kwargs.get('interface'))
        elif 'policy' in kwargs:
            filter = 'match policy {}'.format(kwargs('policy'))
        elif 'epi' in kwargs:
            filter = 'match epi {}'.format(kwargs('epi'))
        else:
            filter = ""

        cmd = "show session {}".format(filter)
        session = self._access.va_cli(cmd)
        if 'session' not in dir():
            logger.error("Failed to get session")
            return None

        return session

    def va_show_counters (self, *args, **kwargs) :
        """
        API to show counters.
        param   : kwargs : dict
        example : va_show_counters(**kwargs)
            kwargs = {
                    'epi'     : uuid|hostname,
                    'counter' : a string of counter name,
            }
        return: 
            :string - counter info or None
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        cmd = 'show counters'
        if 'epi' in kwargs:
            epi = kwargs.get('epi')
            cmd += ' epi {}'.format(epi)

        if 'counter' in kwargs:
            counter = kwargs.get('counter')
            cmd += ' |grep {}'.format(counter)

        counter_info = self._access.va_cli(cmd)
        if 'counter_info' not in dir():
            logger.error("Failed to get counters")
            return None

        return counter_info

    def va_check_counters(self, *args, **kwargs):

        """
        API to check counters.
        param   : kwargs : dict
        example : va_show_chassis_epi(**kwargs)
            kwargs = {
                    'epi'     : uuid|hostname,
                    'counter' : a string of counter name,
                    'counter_value' : a value of counter,
            }
        return:
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        if 'epi' not in kwargs:
            raise ValueError("epi is mandatory parameter!\n") 
        epi = kwargs.get('epi')
        
        if 'counter' in kwargs:
            counter = kwargs.get('counter')
        else:
            counter = 'Turbo from'

        if 'counter_value' in kwargs:
            counter_value = int(kwargs.get('counter_value'))
        else:
            counter_value = 0

        data = {"epi" : epi, "counter" : counter}
        counter_info = self.va_show_counters(**data)
        if 'counter_info' not in dir():
            logger.error('Failed to get counters')
            return False

        pat = re.compile(r'{}:\s+(\d+)'.format(counter))
        match_result = pat.search(counter_info)
        if match_result is None:
            logger.error('Failed to get info related to "{}" counter'.format(
                counter))
            return False

        got_counter_value = int(match_result.group(1))
        if counter_value != got_counter_value:
            logger.error('Expected value: {}, actual value: {}'.format(
                counter_value, got_counter_value))
            return False

        logger.info('Succeed to check counters')
        return True

    def va_is_3_0(self, *args, **kwargs):
        """
        API to check if version of system is 3.0
        return:
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        version_info = self.va_get_version()
        if version_info is None:
            return False
        if re.search(r'^3\.0\.', version_info) is None:
            logger.error('Current version is not 3.0')
            return False

        logger.info('Current version is 3.0')
        return True

    def va_is_3_1(self, *args, **kwargs):
        """
        API to check if version of system is 3.1
        return:
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        version_info = self.va_get_version()
        if version_info is None:
            return False
        if re.search(r'^3\.1\.', version_info) is None:
            logger.error('Current version is not 3.1')
            return False

        logger.info('Current version is 3.1')
        return True

    def va_delete_db(self, *args, **kwargs):
        """
        API to delete DB files
        return:
            :bool - True on success or False on failure:
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)
        db_path = '/opt/varmour/db/'
        shell = self._access.va_shell
        shell("rm -f {}chasd_*.db".format(db_path))
        shell("sync")
        time.sleep(0.1)
        db_info = shell("ls -al {} | grep chasd |grep -v chasd_stat -c".format(db_path))
        db_count = int(db_info.split('\n')[-2])
        if db_count != 0:
            logger.error("DB files can't be deleted!")
            return False

        logger.info("DB files are deleted")
        return True


