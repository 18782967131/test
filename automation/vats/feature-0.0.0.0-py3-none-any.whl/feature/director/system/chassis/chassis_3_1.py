"""coding: utf-8

Copyright 2016 vArmour Chassis private.
All Rights reserved. Confidential

Chassis related features. A superset of features apply
to the product 'dir'.
.. moduleauthor:: xliu@varmour.com
"""

import re
from feature.director.system.system_3_1 import VaSystem as System
from feature import logger

class VaChassis(System):
    """
    Chassis realted API.
    """
    def va_get_active_device(self):
        """
        get the number of active devices of director and CP/EP

        kwargs: None

        returns:
            dict : {'active_devices': The number of active devices except EPI,
                    'active_epis': The number of active EPIs
                    }
        Examples:
            va_get_active_device()
        """
        count_dev = 0
        count_epis = 0
        return_value = {}

        chassis_info = self.va_show_chassis()
        dev_status = chassis_info.get('devices status')
        total_dev_counts = dev_status.get('total devices connected')
        inactive_devs = dev_status.get('inactive devices')

        match_tol_act_devs = re.search(r'^(\d+)\s+\(',total_dev_counts, re.I | re.M)
        if match_tol_act_devs is not None:
            total_dev_count = match_tol_act_devs.group(1)
            if int(total_dev_count) != 0:
                logger.debug("The number of devices are %s" % total_dev_count)
            else:
                logger.warn("The number of total connected devices is incorrect")
        else:
            logger.error("Failed to get 'total devices connected' \
        information via 'show chassis'")

        match_rt = re.search(r'(\d+)\s+\(', inactive_devs, re.I|re.M)
        if match_rt is not None:
            inactive_dev_count = match_rt.group(1)
            if int(inactive_dev_count) == 0:
                logger.debug("No inactivate devices")
            else:
                logger.warn("The number of inactive device are %s" % inactive_dev_count)
        else:
            logger.error("Failed to get information of inactive device")

        #number of activate devices except EPI.
        count_dev = int(total_dev_count) - int(inactive_dev_count)
        return_value['active_devices'] = count_dev

        #get number of activate EPIs
        rt = self._access.va_cli('show chassis epi')
        match_rt = re.search(r'Total active EPIs:\s+(\d+)', rt, re.I | re.M)
        if match_rt is not None:
            count_epis = match_rt.group(1)
            if count_epis != 0:
                logger.debug("The number of EPIs are %s" % count_epis)
            else:
                logger.debug("No activate EPIs")
        else:
            logger.error("Failed to get information of EPIs")
        return_value['active_epis'] = count_epis

        return return_value