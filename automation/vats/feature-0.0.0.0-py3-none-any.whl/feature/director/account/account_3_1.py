"""coding: utf-8

Copyright 2016 vArmour Networks private.
All Rights reserved. Confidential

Configure management user account related APIs.

.. moduleauthor:: xliu@sigma-rt.com
"""

import sys, re, time, copy
from collections import namedtuple
from feature.common import VaFeature
from feature import logger
from vautils.dataparser.string import va_parse_basic, va_parse_as_lines


class VaAccount(VaFeature):
    """
    Configure management user account
    """

    def va_add_user(self, *args, **kwargs):

        """
           Add user
           param      : kwargs : dict
                       kwargs = {
                                   'name'    : 'account user name',
                                   'password': 'account user password',
                                   'role'    : 'account user role' [admin|operator|reader]
                                   'is_commit': True|False,  Optional parameters
                                  }
           return: Tuple
               True, cmd
               False, error log

            Example    : va_add_user(**kwargs)
                      kwargs = {
                       'name'    : 'varmour_no_cli',
                       'password': 'vArmour123',
                       'role'    : 'admin'
                       'is_commit': True
                      }
        """
        logger.info("\nIn subroutine: " + sys._getframe().f_code.co_name)

        if not 'name' in kwargs:
            raise ValueError("name is mandatory parameter!\n")

        if not 'password' in kwargs:
            raise ValueError("password is mandatory parameter!\n")

        if not 'role' in kwargs:
            raise ValueError("role is mandatory parameter!\n")

        if not 'is_commit' in kwargs:
            is_commit = True
        else:
            is_commit = kwargs.get('is_commit')

        name = kwargs.get('name')
        password = kwargs.get('password')
        role = kwargs.get('role')
        cmd = 'set system user {} role {}'.format(name,role)
        cmd1 = 'set system user {} password'.format(name)
        err_cmd,err_msg = self._access.va_config(cmd, commit=False,exit=False)
        err_cmd1,err_msg1 = self._access.va_config(cmd1, **{'handle_password':password})

        if err_cmd is not None or err_msg is not None or\
            err_cmd1 is not None or err_msg1 is not None:
            logger.error('Failed to add user {}'.format(name))
            return False, err_msg

        logger.info('Succeed to add user {}'.format(name))
        return True,[cmd,cmd1]