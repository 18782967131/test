
"""coding: utf-8

Copyright 2016 vArmour Networks private.
All Rights reserved. Confidential

Feature implements the base class for the linux product feature framework
The features for the specific distributions must inherit from this class.

.. moduleauthor:: ppenumarthy@varmour.com
"""

supported = ('3.1.qa', '3.1.0', '3.1.0B1','3.1.0B2', '3.1')
version_map = {
    '3.1' : '3_1',
}

from feature.common.accesslib import VaAccess


class VaFeature(object):
    """
    Feature implements the base class for director product features.
    """
    def __init__(self, resource=None):
        """
        Initialize the feature object for director product.

        Kwargs:
            :resource (VarmourVm Lab object)
        """
        self._resource = resource

        if not resource.get_access():
            access = VaAccess.get(resource)
            self._access = access(resource)
            resource.set_access(self._access)
        else:
            self._access = resource.get_access()

    def __del__(self):
        """
        Custom delete to unlink the references to access and resource
        objects.
        """
        self._access = None
        self._resource = None
