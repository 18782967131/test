feature
-------
Package implements libraries to configure features on varmour
products using CLI, REST, or shell.


