"""coding: utf-8

Copyright 2016 vArmour Networks private.
All Rights reserved. Confidential

Restutil is a tool for calling rest requests via http methods

.. moduleauthor:: ckung@varmour.com
"""

from requests.packages.urllib3.exceptions import InsecureRequestWarning
import requests
import json
import pprint
from access import logger
from requests.exceptions import *

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

DEFAULT_HEADER = {'content-type': 'application/json'}
SUPPORTED_VERB = ['GET', 'POST', 'PUT', 'DELETE']


class Restutil():
    """
    Restutil class
    """

    def __init__(self, verbose=False, get_json_resp=True, format_json_log=False):
        """
        constructor

        :param verbose: | True - print out all rest messages
                        | False - all rest messages will not be printed
        :type verbose: bool
        :param get_json_resp: | True - return of rest request only returns message body of type str
                              | False - the return of rest request returns of type requests.models.Response
        :type get_json_resp: bool
        :param format_json_log: | True - logger will pretty print json strings
                                | False - logger will not pretty print json strings
        :type format_json_log: bool
        """
        self.__verbose = verbose
        self.__get_json_resp = get_json_resp
        self.__format_json_log = format_json_log

    @property
    def verbose(self):
        """
        verbose getter

        :return: True or False
        :type: bool
        """
        return self.__verbose

    @verbose.setter
    def verbose(self, verbose):
        """
        verbose setter

        :param verbose: | True - print out all rest messages
                        | False - all rest messages will not be printed
        :type verbose: bool
        """
        if type(verbose) is bool:
            self.__verbose = verbose

    @property
    def get_json_resp(self):
        """
        get_json_resp getter

        :return: True or False
        :type: bool
        """
        return self.__get_json_resp

    @get_json_resp.setter
    def get_json_resp(self, get_json_resp):
        """
        get_json_resp setter

        :param get_json_resp: | True - return of rest request only returns message body of type str
                              | False - return of rest request returns of type requests.models.Response
        :type get_json_resp: bool
        """
        if type(get_json_resp) is bool:
            self.__get_json_resp = get_json_resp

    @property
    def format_json_log(self):
        """
        format_json_log getter

        :return: True or False
        :type: bool
        """
        return self.__format_json_log

    @format_json_log.setter
    def format_json_log(self, format_json_log):
        """
        format_json_log setter

        :param format_json: | True - logger will pretty print json strings
                            | False - logger will not pretty print json strings
        :type format_json_log: bool
        """
        if type(format_json_log) is bool:
            self.__format_json_log = format_json_log

    def request(self, verb, url, **kwargs):
        """
        rest request

        :param verb: get, post, put, delete
        :type verb: str
        :param url: url
        :type url: str
        :param kwargs: | header (dict) - HTTP header
                       | auth (HTTPBasicAuth) - HTTPBasicAuth obj
                       | params (str) - URL parameters
                       | data (dict) - Rest body content
        :return:
        """
        headers = kwargs.get('headers', DEFAULT_HEADER)
        auth = kwargs.get('auth', None)
        params = kwargs.get('params', None)
        data = kwargs.get('data', None)
        verb = verb.upper()
        if self.__verbose:
            logger.debug('----------begin {} request----------'.format(verb))
            logger.debug('url: {}'.format(url))
            logger.debug('params: {}'.format(params))
            logger.debug('data: {}'.format(data))
            logger.debug('......{} response result......'.format(verb))

        if data:
            data = json.dumps(data, ensure_ascii=False)

        try:
            if verb.upper() not in SUPPORTED_VERB:
                raise Exception('Http Request Verb')

            response_obj = requests.request(verb.upper(), url, params=params, data=data, headers=headers, auth=auth,
                                            verify=False)

            if self.__verbose:
                logger.debug('{} response status {}'.format(verb, response_obj.status_code))

            response_json = response_obj.json()
            if 'status' in response_json.keys() and not ('ok' in response_json['status'] or '200' in response_json['status']):
                raise RequestException
            if 'auth' in response_json.keys() and 'status' in response_json['auth']:
                raise RequestException

        except URLRequired:
            self.__show_error_log(verb, url, 'URL Not Found', response_obj)
            return self.__return_obj(False, response_obj)
        except HTTPError:
            self.__show_error_log(verb, url, 'HTTP', response_obj)
            return self.__return_obj(False, response_obj)
        except RequestException:
            self.__show_error_log(verb, url, 'Request Exception', response_obj)
            return self.__return_obj(False, response_obj)
        except Timeout:
            self.__show_error_log(verb, url, 'Timeout', response_obj)
            return self.__return_obj(False, response_obj)
        except ConnectionError:
            self.__show_error_log(verb, url, 'Connection', response_obj)
            return self.__return_obj(False, response_obj)
        except TooManyRedirects:
            self.__show_error_log(verb, url, 'Too Many Redirects', response_obj)
            return self.__return_obj(False, response_obj)
        except Exception as e:
            self.__show_error_log(verb, url, 'Exception', e)
            return self.__return_obj(False, response_obj)
        else:
            if self.__verbose:
                if self.__format_json_log:
                    logger.debug('{} response message:\n{}'.format(verb, pprint.pformat(response_obj.json())))
                else:
                    logger.debug('{} response message:\n{}'.format(verb, response_obj.json()))
                logger.debug('----------end {} request----------\n'.format(verb))
            return self.__return_obj(True, response_obj)

    def __show_error_log(self, verb, url, reason, response_message):
        """

        :param verb:
        :param url:
        :param reason:
        :param response_message:
        :return:
        """
        logger.error('error sending {} to url {}'.format(verb, url))
        logger.error('reason: {}'.format(reason))
        if self.__format_json_log and type(response_message) is requests.models.Response:
            logger.error('message:\n{}'.format(pprint.pformat(response_message.json())))
        elif not self.__format_json_log and type(response_message) is requests.models.Response:
            logger.error('message:\n{}'.format(response_message.json()))
        else:
            logger.error('message:\n{}'.format(response_message))
        logger.debug('----------end {} request----------\n'.format(verb))

    def __return_obj(self, status_bool, response_obj):
        """

        :param status_bool:
        :param response_obj:
        :return:
        """
        if self.__get_json_resp:
            return status_bool, response_obj.json()
        return status_bool, response_obj
