access
------
Package implements remote access to vms setup in an esx datacenter.
The access can be used to run CLI, SHELL commands and RESTful actions
on the linux like OS's running on the vms.

Currently Bash like shell, Terminalserver supporting CLI operations, and
any REST server can be accessed.

For CLI and Bash the package uses Paramiko, and for REST it uses
Requests. For the exact versions please refer to requirements.txt 


